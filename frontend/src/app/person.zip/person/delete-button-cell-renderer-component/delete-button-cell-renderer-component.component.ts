import { Component, OnInit } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';
import { ICellRendererParams } from 'ag-grid-community';
import { CommonService } from 'src/app/services/common.service';
@Component({
  selector: 'app-delete-button-cell-renderer-component',
  templateUrl: './delete-button-cell-renderer-component.component.html',
  styleUrls: ['./delete-button-cell-renderer-component.component.css']
})
export class DeleteButtonCellRendererComponentComponent implements ICellRendererAngularComp  {
  params: any;

  constructor(public commonservice:CommonService) { }
  agInit(params: any): void {
    this.params = params;
  } 

  refresh(params: any): boolean {
    return true;
  }
 // testtt: any;  
  
  
  onClick(): void {
  

    console.log("oooooooo", this.params.data.id);

console.log("uuuu", this.params.data);
   const idds  = this.params.data.id;

   for (let key in this.params.data) {
    // If the key is not "id", remove it from the object
    if (key !== 'id') {
      delete this.params.data[key];
    }
  }

  
console.log("RRRRRRR", this.params.data);
   // const testtt ={"id":id};
   //dynamicObj.id = 'John';
  //  const parsedJson = {
  //   "id": id
  // };  
            
  // const parsedJson: any = {      
  //   id:this.params.data.id
  //   }     
  const jsonData = `{"id": '${idds}'}`;

   // const jsonData = {id:this.params.data.id}; // JSON data with single quotes
const jsonString = jsonData.replace(/'/g, '"'); // Replace single quotes with double quotes
const parsedJsonn = JSON.parse(jsonString);
const tt=JSON.stringify(parsedJsonn); 
  console.log("TTTTTT",tt);   

   // const parsedJsonn = JSON.parse(jsonString);
 
   //alert(fin);
     this.commonservice.deleteUser(this.params.data).subscribe((response: any) => {
        console.log("RRRRR", response);
        if(response){
          document.location.reload();
        }
        // do something with response
      }, (error: any) => {
        console.log("GGGG", error);
        // handle error
      });
  }   

  ngOnInit(): void {
  }

}
