import { ChangeDetectorRef, Component, OnInit, ViewChild } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
//import { DeleteButtonCellRendererComponentComponent } from './person/delete-button-cell-renderer-component.component';

import { DeleteButtonCellRendererComponentComponent } from './delete-button-cell-renderer-component/delete-button-cell-renderer-component.component';

import { CommonService } from 'src/app/services/common.service';
import { AgGridAngular } from 'ag-grid-angular';
import { GridApi, GridReadyEvent } from 'ag-grid-community';
import { ColDef } from 'ag-grid-community';
import { Router } from '@angular/router';
 
   
@Component({
  selector: 'app-person',
  templateUrl: './person.component.html',
  styleUrls: ['./person.component.css']
})
export class PersonComponent implements OnInit {
  rowData: any[] = [];
  CustomerData:any;
 // columnDefs:any[] = [];
  gridApi: any;
  gridColumnApi: any;
  //onRowDataUpdated: any;
 // deleteButtonCellRenderer: any;
 context: any = {};
  inputRow = {};
  @ViewChild('agGrid') agGrid: AgGridAngular | undefined;
  //router: any;
 
 // deleteButtonCellRenderer: any;

  // deleteButtonCellRenderer(params: { data: { id: any; }; }) {
  //   var deleteButton = document.createElement('button');
  //   deleteButton.innerHTML = 'Delete';
  //   deleteButton.addEventListener('click', () => {
  //     this.commonservice.deleteUser(params.data.id).subscribe((response: any) => {
  //       console.log(response);
  //       // do something with response
  //     }, (error: any) => {
  //       console.log("GGGG", error);
  //       // handle error
  //     });
  //   });
  //   return deleteButton;
  // }

  constructor(public http: HttpClient, private router: Router, public commonservice: CommonService, private cdr: ChangeDetectorRef) { }
  


  gridOptions = {
    rowData: [],
    defaultColDef: {
      editable: true,
      sortable: true,
      filter: true
    
    },
   onCellValueChanged: this.onCellValueChanged,
   onCreateRowReady: this.onCreateRowReady,
   onRowAddedToGrid: this.onRowAddedToGrid,
   onRowCreated: this.onRowCreated,
   pinnedTopRowData: [this.inputRow],
 
   

   // onRowDataUpdated: this.onRowDataUpdated.bind(this)
    // ... grid options
  };  
    

  columnDefs: ColDef[] =[
    { headerName: 'id', field: 'id', editable: false },
    { headerName: 'name', field: 'name' },
    { headerName: 'state', field: 'state' },
    { headerName: 'zip', field: 'zip' },
    { headerName: 'amount', field: 'amount' },
    { headerName: 'qty', field: 'qty' },
    { headerName: 'item', field: 'item' },
    {
      headerName: 'Delete',
      cellRenderer: 'deleteButtonCellRenderer',
      maxWidth: 100,
      editable: false
    }
  ]  

  frameworkComponents = {
    deleteButtonCellRenderer: DeleteButtonCellRendererComponentComponent,
  };
  


    
  onGridReady(params: any) {

    console.log("RRRRRR");
    this.gridApi = params.api;
   // console.log("sssss", this.gridApi);
    this.gridColumnApi = params.columnApi;
}


  // deleteButtonCellRenderer(params: any) {
  //   const button = document.createElement('button');
  //   button.innerText = 'Delete';
  //   button.addEventListener('click', () => this.onDeleteRowClicked(params.node));
  //   return button;
  // }

  // onDeleteRowClicked(rowNode: any) {
  //   // get the ID of the row to be deleted
  //   const id = rowNode.data.id;
  //   // delete the row from the grid
  //   this.gridApi.applyTransaction({ remove: [rowNode.data] });
  //   // make an API call to delete the row from the server
  //   this.http.delete(`http://localhost/api/${id}`).subscribe(response => {
  //     // handle the API response as needed
  //   });
  // }


  onCreateRowReady(event: any) {  
    console.log("bbbbbbb",event);
  }

  onRowAddedToGrid(node: any) {
    console.log(node);
  }
  onRowCreated(node: any) {
    console.log(node);
  }


    
  onCellValueChanged(event: any) { 
    //alert("huhuu");  
    console.log("ggggg",event.data);

    if (event.data.hasOwnProperty('id')) {
      this.commonservice.updatedetails(event.data).subscribe(res=>{
        console.log('API response:', res);
      }, (error) => {
        console.error('API error:', error);
    
  });
    } else {
      //this.router.navigate(['/person']);
         this.commonservice.postdetails(event.data).subscribe(res=>{
        console.log('API response:', res);
        if(res){
          document.location.reload();
         // this.router.navigateByUrl('/person');
        }       
        //this.router.navigateByUrl('/person');
       
      //  this.cdr.detectChanges();  
      }, (error) => {
        console.error('API error:', error);
    
  });

 // console.log('PPPPPPPP', this.gridApi);

    }

    
  

    // this.http.put('http://localhost/api/', event.data).subscribe(response => {
    //   console.log(response);
    //   // handle the API response as needed
    // });
   //this.fetchUpdatedRowData(event.data);
    
    }

    // refreshGridData() {
    //   this.agGrid.api.refreshCells();
    // }



  onRowValueChanged(params: any) {

  
    alert("rupesh");
    console.log("ggggg",params)


    // const updatedData = this.fetchUpdatedRowData(params.data);
    // updatedData.then((data) => {
    //   params.node.setData(data);
    //   this.gridApi.refreshCells({ rowNodes: [params.node], force: true });
    // });
  }

  

 
  // columnDefs = [
  //   { headerName: 'id', field: 'id' },
  //   { headerName: 'name', field: 'name' },
  //   { headerName: 'state', field: 'state' },
  //   { headerName: 'zip', field: 'zip' },
  //   { headerName: 'amount', field: 'amount' },
  //   { headerName: 'qty', field: 'qty' },
  //   { headerName: 'item', field: 'item' }
  // ];
  

  // rowData = [   
  //   { make: 'Toyota', model: 'Celica', price: 35000 },
  //   { make: 'Ford', model: 'Mondeo', price: 32000 },
  //   { make: 'Porsche', model: 'Boxter', price: 72000 }
  // ];


  
  ngOnInit() {    
    this.context.createFn = async () => 1;  
    this.commonservice.Getalldata().subscribe((result) => {
       
      this.CustomerData=result;
      this.rowData=this.CustomerData.data;
    //  this.columnDefs=this.CustomerData.headerdata;  
    //  console.log("ppppppp", result);
     // console.log("ssssssSSS", headerRow[0].length);
      

    //   for (let i = 0; i < headerRow.length; i++) {
    //   //  headerRow[i].style.backgroundColor = "";
    //   //  headerRow[i].style.cursor = "pointer!important";
    //   for (let j = 0; j < headerRow[i].length; j++) {
    //     console.log("RRRRRR", headerRow[i][j]);
    //   //  { id: headerRow[i][j], name: headerRow[i][j], state: headerRow[i][j] },
    //   }

    //  // console.log("RRRRRR", headerRow[0].lenght);
    //   //console.log("lenght", headerRow[i][i]);
    //   }

    });
  
    

  }
 

 
    //this.functiontestnew(); 
    //const persondata=event.data;
    // const test= {
    //   "id":3,
    //   "name":"oioio",
    //   "state":"bhopal",
    //   "zip":"4567890",
    //   "amount":"6500",
    //   "qty":"5",
    //   "item":"tv"
    //   } 
      
  
   
   

      
    // if (event.newValue !== event.oldValue) {

    //   if (!event.node.changedValues)
    //   event.node.changedValues = [];

    //   event.node.changedValues.push(event['column']['colId']);
  

  
    

}

